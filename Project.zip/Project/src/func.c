/*
 * header_func.c
 *
 *  Created on: 5.08.2020 �.
 *      Author: User
 */
#include "func.h"
#include <stdio.h>
//-------------------------------------------------------------------------
void Print(int *input, int len)
{
	for(int i = 0; i < len; i++)
	{
		printf("%i ", input[i]);
	}
	printf("\n");
}
//-------------------------------------------------------------------------
void Sort(int *input, int len)
{
	for(int i = 0; i < len; i++)
	{
		for(int j = 0; j < len - 1; j++)
		{
			if(input[j] > input[j + 1])
			{
				int t = input[j];
				input[j] = input[j + 1];
				input[j + 1] = t;
			}
		}
	}
}
//-------------------------------------------------------------------------
void Reverse(int *input, int len)
{
	for(int i = 0; i < len / 2; i++)
	{
		int t = input[i];
		input[i] = input[len - i - 1];
		input[len - i - 1] = t;
	}
}
//-------------------------------------------------------------------------
int BinarySearch(int *ar, int l, int r, int x)
{
	while (l < r)
	{
		int m = (l + (r - l)) / 2;

		if(ar[m] == x)
		{
			return m;
		}
		else if (ar[m] > x)
		{
			l = m + 1;
		}
		else
		{
			r = m - 1;
		}
	}
	return -1;
}
//-------------------------------------------------------------------------



