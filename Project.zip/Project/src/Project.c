/*
 ============================================================================
 Name        : Project.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, ANSI-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "func.h"

int main(void)
{
	int ar[10] = { 4, 3, 9, 1, 8, 2, 7, 5, 6, 0 };
	int len = (sizeof(ar) / sizeof(ar[0]));

	printf("Unsorted - ");
	Print(ar, len);

	printf("Sorted   - ");
	Sort(ar, len);
	Print(ar, len);

	printf("Reversed - ");
	Reverse(ar, len);
	Print(ar, len);

	int num = 7;
	int res = BinarySearch(ar, 0, len, num);
	printf("The number %i is at index %i", num, res);

	return EXIT_SUCCESS;
}
