/*
 * header.h
 *
 *  Created on: 5.08.2020 �.
 *      Author: User
 */

#ifndef HEADER_H_
#define HEADER_H_

void Print(int *input, int len);

void Sort(int *input, int len);

void Reverse(int *input, int len);

int BinarySearch(int *ar, int l, int r, int x);

#endif /* HEADER_H_ */




